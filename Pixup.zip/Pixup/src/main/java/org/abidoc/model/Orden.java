package org.abidoc.model;

import java.sql.Timestamp;

public class Orden {
    private int id;
    private float costoTotal;
    private Timestamp fecha;
    private int cantidadTotal;
    private int estatusEnvio;
    private float costoEnvio;
    private int idUsuario;

    public Orden(int id, float costoTotal, Timestamp fecha, int cantidadTotal, int estatusEnvio, float costoEnvio, int idUsuario) {
        this.id = id;
        this.costoTotal = costoTotal;
        this.fecha = fecha;
        this.cantidadTotal = cantidadTotal;
        this.estatusEnvio = estatusEnvio;
        this.costoEnvio = costoEnvio;
        this.idUsuario = idUsuario;
    }
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public float getCostoTotal() {
        return costoTotal;
    }

    public void setCostoTotal(float costoTotal) {
        this.costoTotal = costoTotal;
    }

    public Timestamp getFecha() {
        return fecha;
    }

    public void setFecha(Timestamp fecha) {
        this.fecha = fecha;
    }

    public int getCantidadTotal() {
        return cantidadTotal;
    }

    public void setCantidadTotal(int cantidadTotal) {
        this.cantidadTotal = cantidadTotal;
    }

    public int getEstatusEnvio() {
        return estatusEnvio;
    }

    public void setEstatusEnvio(int estatusEnvio) {
        this.estatusEnvio = estatusEnvio;
    }

    public float getCostoEnvio() {
        return costoEnvio;
    }

    public void setCostoEnvio(float costoEnvio) {
        this.costoEnvio = costoEnvio;
    }

    public int getIdUsuario() {
        return idUsuario;
    }

    public void setIdUsuario(int idUsuario) {
        this.idUsuario = idUsuario;
    }
}
