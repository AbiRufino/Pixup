package org.abidoc.model;

import java.sql.Time;

public class Cancion {
    private int id;
    private String titulo;
    private Time duracion;
    private int idDisco;

    public Cancion(int id, String titulo, Time duracion, int idDisco) {
        this.id = id;
        this.titulo = titulo;
        this.duracion = duracion;
        this.idDisco = idDisco;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTitulo() {
        return titulo;
    }

    public void setTitulo(String titulo) {
        this.titulo = titulo;
    }

    public Time getDuracion() {
        return duracion;
    }

    public void setDuracion(Time duracion) {
        this.duracion = duracion;
    }

    public int getIdDisco() {
        return idDisco;
    }

    public void setIdDisco(int idDisco) {
        this.idDisco = idDisco;
    }
}
