package org.abidoc.model;

public class DetalleOrden {
    private int idDisco;
    private int idOrden;
    private int cantidad;
    private float costo;

    public DetalleOrden(int idDisco, int cantidad, int idOrden, float costo) {
        this.idDisco = idDisco;
        this.cantidad = cantidad;
        this.idOrden = idOrden;
        this.costo = costo;
    }

    public int getIdDisco() {
        return idDisco;
    }

    public void setIdDisco(int idDisco) {
        this.idDisco = idDisco;
    }

    public int getIdOrden() {
        return idOrden;
    }

    public void setIdOrden(int idOrden) {
        this.idOrden = idOrden;
    }

    public int getCantidad() {
        return cantidad;
    }

    public void setCantidad(int cantidad) {
        this.cantidad = cantidad;
    }

    public float getCosto() {
        return costo;
    }

    public void setCosto(float costo) {
        this.costo = costo;
    }
}

