package org.abidoc.model;

import org.abidoc.model.Usuario;

    public class Main {
        public static void main(String[] args) {
            // Crear un objeto de tipo Usuario
            Usuario usuario = new Usuario();
            usuario.setNombre("Juan");
            usuario.setEmail("juan@example.com");


            System.out.println("Usuario creado: " + usuario.getNombre() + " - " + usuario.getEmail());
        }